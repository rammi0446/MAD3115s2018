//
//  TableItems.swift
//  Day2
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class TableItems{
    static var titles : [String] = ["Audio", "Video", "WebView", "Calender", "Location", "Contacts"]
    static var subTitles : [String] = ["Hear it clear", "Watch is better ", "World is Your", "Time is not yours", "Be everywhere", "Stay connnected" ]
    static var images : [String] = ["Audio", "Video", "Web", "Calendar", "Location", "Contacts"]
}
