//
//  ViewController.swift
//  Day2
//
//  Created by MacStudent on 2018-08-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet var switchRemember: UISwitch!
    
    @IBAction func btnSignUp(_ sender: Any) {
        
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let signUpVC = mainSB.instantiateViewController(withIdentifier: "SignUpScene")
        navigationController?.pushViewController(signUpVC, animated: true)
    }
    @IBAction func btnSignIn(_ sender: Any) {
        if validateUser(){
            
            if switchRemember.isOn{
                //save data
                UserDefaults.standard.set(txtEmail.text, forKey: "email")
                UserDefaults.standard.set(txtPassword.text, forKey: "password")
            }else{
                //remove data
                UserDefaults.standard.removeObject(forKey: "email")
                UserDefaults.standard.removeObject(forKey: "password")
            }
            
            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeVC = mainSB.instantiateViewController(withIdentifier: "HomeScene")
          //  self.present(homeVC,animated: true,completion: nil)
            navigationController?.pushViewController(homeVC, animated: true)
        }else{
            let infoAlert = UIAlertController(title: "Invalid User", message: "Incorrect username and/or password", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: nil))
            self.present(infoAlert,animated: true,completion: nil)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //get the data from Userdefaults
        if let email = UserDefaults.standard.string(forKey: "email"){
            txtEmail.text = email
        }
        
        if let password = UserDefaults.standard.value(forKey: "password"){
            txtPassword.text = password as? String
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func validateUser() -> Bool{
        if txtEmail.text == "test" && txtPassword.text == "test"{
            return true
        }else{
            return false
        }
    }

}

