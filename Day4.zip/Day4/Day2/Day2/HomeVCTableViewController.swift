//
//  HomeVCTableViewController.swift
//  Day2
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class HomeVCTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //displayUsers()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return TableItems.titles.count
    }
//    func displayUsers(){
//        var userList = User.getAllUsers()
//
//        for user in userList.values{
//            print("Name : \(user.name)")
//            print("Email : \(user.email)")
//            print("Date of birth : \(user.dob)")
//        }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomeCell", for: indexPath) as! HomeTVCell
        cell.lblTitle.text = TableItems.titles[indexPath.row]
        cell.lblSubTitle.text = TableItems.subTitles[indexPath.row]
        cell.imgViewHome.image = UIImage(named: TableItems.images[indexPath.row])
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let infoAlert = UIAlertController(title: "Manu Action", message: TableItems.titles[indexPath.row], preferredStyle: .alert)
//        infoAlert.addAction(UIAlertAction(title: "So what !!!", style: .default, handler: nil))
//        self.present(infoAlert, animated: true, completion: nil)
        switch indexPath.row{
        case 0:
            print("audio performed")
        case 1:
            print("video performed")
        case 2:
            print("WebView performed")
            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let webVC = mainSB.instantiateViewController(withIdentifier: "WebScene")
            navigationController?.pushViewController(webVC, animated: true)
        case 3:
            print("calendar performed")
        case 4:
            print("location performed")
        case 5:
            print("Contact performed")
        default:
            print("no action")
        }
        
        
    }
}

