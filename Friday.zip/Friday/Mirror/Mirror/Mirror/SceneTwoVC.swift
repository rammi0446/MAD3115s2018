//
//  SceneTwoVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-03.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class SceneTwoVC: UIViewController {

    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var txtPwd: UITextField!
    
    
    @IBOutlet weak var btnRegister: UIButton!
    @IBAction func btnSubmit(_ sender: UIButton) {
        
        var alert = UIAlertController(title: "", message: "", preferredStyle: .actionSheet)
        
        
        if txtPwd.text == "" || txtUsername.text == ""{
            
            if txtPwd.text == "" && txtUsername.text == ""{
                alert = UIAlertController(title: "Warning", message: "Enter Username and Password", preferredStyle: .actionSheet)
            }
            else if txtUsername.text == ""{
                alert = UIAlertController(title: "Warning", message: "Enter Username", preferredStyle: .actionSheet)
            }
            else if txtPwd.text == ""{
                alert = UIAlertController(title: "Warning", message: "Enter Password", preferredStyle: .actionSheet)
            }
            
            self.present(alert, animated: true)
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))
        }
        else{
            lblMessage.isHidden = false
            lblMessage.text = "Welcome "+txtUsername.text!
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblMessage.isHidden = true
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
