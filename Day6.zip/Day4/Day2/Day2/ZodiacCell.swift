//
//  ZodiacCell.swift
//  Day2
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ZodiacCell: UICollectionViewCell {
    
    @IBOutlet weak var imgZodiac: UIImageView!
    
    @IBOutlet weak var lblZodiac: UILabel!
}
